import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;

/**
 * Controller for the Accessibility Settings window.
 * Allows the user to apply colorblind support modes, large text mode,
 * or reset the application back to default display settings.
 */
public class AccessibilitySettingsController {

    @FXML
    private RadioButton defaultModeRadio;

    @FXML
    private RadioButton redGreenModeRadio;

    @FXML
    private RadioButton blueYellowModeRadio;

    @FXML
    private CheckBox largeTextCheckBox;

    private static Scene currentScene;

    public static void setMainScene(Scene scene) {
        currentScene = scene;
    }

    @FXML
    public void initialize() {
        defaultModeRadio.setSelected(
                !AccessibilityManager.isRedGreenModeEnabled()
                        && !AccessibilityManager.isBlueYellowModeEnabled()
        );

        redGreenModeRadio.setSelected(AccessibilityManager.isRedGreenModeEnabled());
        blueYellowModeRadio.setSelected(AccessibilityManager.isBlueYellowModeEnabled());
        largeTextCheckBox.setSelected(AccessibilityManager.isLargeTextModeEnabled());
    }

    @FXML
    private void handleApply() {
        if (defaultModeRadio.isSelected()) {
            AccessibilityManager.setDefaultMode();
        } else if (redGreenModeRadio.isSelected()) {
            AccessibilityManager.setRedGreenMode();
        } else if (blueYellowModeRadio.isSelected()) {
            AccessibilityManager.setBlueYellowMode();
        }

        AccessibilityManager.setLargeTextMode(largeTextCheckBox.isSelected());
        AccessibilityManager.applySettings(currentScene);

        closeWindow();
    }

    @FXML
    private void handleReset() {
        AccessibilityManager.resetAll();
        AccessibilityManager.applySettings(currentScene);

        defaultModeRadio.setSelected(true);
        largeTextCheckBox.setSelected(false);

        closeWindow();
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) largeTextCheckBox.getScene().getWindow();
        stage.close();
    }
}