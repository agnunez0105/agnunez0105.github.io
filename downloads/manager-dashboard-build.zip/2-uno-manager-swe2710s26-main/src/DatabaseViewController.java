import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;

public class DatabaseViewController {
    private static final DecimalFormat TWO_DECIMAL_FORMAT = new DecimalFormat("0.##");

    @FXML private TableView<EmployeeRow> employeesTable;
    @FXML private TableColumn<EmployeeRow, Integer> employeeIdCol;
    @FXML private TableColumn<EmployeeRow, String> employeeNameCol;

    @FXML private TableView<DailyMetricRow> dailyMetricsTable;
    @FXML private TableColumn<DailyMetricRow, Integer> dailyEmployeeIdCol;
    @FXML private TableColumn<DailyMetricRow, String> metricDateCol;
    @FXML private TableColumn<DailyMetricRow, Double> avgBpmCol;
    @FXML private TableColumn<DailyMetricRow, Double> avgReadinessCol;
    @FXML private TableColumn<DailyMetricRow, Double> totalStepsCol;
    @FXML private TableColumn<DailyMetricRow, Integer> sampleCountCol;

    @FXML private TableView<MetricRow> metricsTable;
    @FXML private TableColumn<MetricRow, Integer> metricIdCol;
    @FXML private TableColumn<MetricRow, Integer> metricEmployeeIdCol;
    @FXML private TableColumn<MetricRow, Double> metricBpmCol;
    @FXML private TableColumn<MetricRow, Integer> metricReadinessCol;
    @FXML private TableColumn<MetricRow, Integer> metricStepsCol;
    @FXML private TableColumn<MetricRow, String> recordedAtCol;

    @FXML private Label readOnlyLabel;

    private Scene mainScene;

    @FXML
    public void initialize() {
        setupColumns();
        loadData();
    }

    public void refreshData() {
        loadData();
    }

    public void setMainScene(Scene scene) {
        this.mainScene = scene;
    }

    @FXML
    public void handleSwitchToMainWindow(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(mainScene);
        stage.show();
    }

    private void setupColumns() {
        employeeIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        employeeNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        dailyEmployeeIdCol.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        metricDateCol.setCellValueFactory(new PropertyValueFactory<>("metricDate"));
        avgBpmCol.setCellValueFactory(new PropertyValueFactory<>("avgBpm"));
        avgReadinessCol.setCellValueFactory(new PropertyValueFactory<>("avgReadinessScore"));
        totalStepsCol.setCellValueFactory(new PropertyValueFactory<>("steps"));
        sampleCountCol.setCellValueFactory(new PropertyValueFactory<>("sampleCount"));
        avgBpmCol.setCellFactory(column -> createTwoDecimalCell());
        avgReadinessCol.setCellFactory(column -> createTwoDecimalCell());
        totalStepsCol.setCellFactory(column -> createTwoDecimalCell());

        metricIdCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        metricEmployeeIdCol.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        metricBpmCol.setCellValueFactory(new PropertyValueFactory<>("bpm"));
        metricReadinessCol.setCellValueFactory(new PropertyValueFactory<>("readinessScore"));
        metricStepsCol.setCellValueFactory(new PropertyValueFactory<>("steps"));
        recordedAtCol.setCellValueFactory(new PropertyValueFactory<>("recordedAt"));
        metricBpmCol.setCellFactory(column -> createTwoDecimalCell());
    }

    private <S> TableCell<S, Double> createTwoDecimalCell() {
        return new TableCell<>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(TWO_DECIMAL_FORMAT.format(item));
                }
            }
        };
    }

    private void loadData() {
        ObservableList<EmployeeRow> employees = FXCollections.observableArrayList();
        ObservableList<DailyMetricRow> dailyMetrics = FXCollections.observableArrayList();
        ObservableList<MetricRow> metrics = FXCollections.observableArrayList();

        String readOnlyUrl = "jdbc:sqlite:file:health_manager.db?mode=ro";

        try (Connection conn = DriverManager.getConnection(readOnlyUrl);
             Statement stmt = conn.createStatement()) {

            try (ResultSet rs = stmt.executeQuery("SELECT id, name FROM employees ORDER BY id")) {
                while (rs.next()) {
                    employees.add(new EmployeeRow(
                            rs.getInt("id"),
                            rs.getString("name")
                    ));
                }
            }

            try (ResultSet rs = stmt.executeQuery(
                    "SELECT employee_id, metric_date, avg_bpm, avg_readiness_score, steps, sample_count " +
                            "FROM daily_metrics ORDER BY metric_date DESC, employee_id")) {
                while (rs.next()) {
                    dailyMetrics.add(new DailyMetricRow(
                            rs.getInt("employee_id"),
                            rs.getString("metric_date"),
                            rs.getDouble("avg_bpm"),
                            rs.getDouble("avg_readiness_score"),
                            rs.getDouble("steps"),
                            rs.getInt("sample_count")
                    ));
                }
            }

            try (ResultSet rs = stmt.executeQuery(
                    "SELECT id, employee_id, bpm, readiness_score, steps, recorded_at " +
                            "FROM metrics ORDER BY recorded_at DESC LIMIT 500")) {
                while (rs.next()) {
                    metrics.add(new MetricRow(
                            rs.getInt("id"),
                            rs.getInt("employee_id"),
                            rs.getDouble("bpm"),
                            rs.getInt("readiness_score"),
                            rs.getInt("steps"),
                            rs.getString("recorded_at")
                    ));
                }
            }

            readOnlyLabel.setText("Read-only mode enabled");
        } catch (Exception e) {
            readOnlyLabel.setText("Failed to load database view");
            e.printStackTrace();
        }

        employeesTable.setItems(employees);
        dailyMetricsTable.setItems(dailyMetrics);
        metricsTable.setItems(metrics);
    }

    public static class EmployeeRow {
        private final Integer id;
        private final String name;

        public EmployeeRow(Integer id, String name) {
            this.id = id;
            this.name = name;
        }

        public Integer getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }

    public static class DailyMetricRow {
        private final Integer employeeId;
        private final String metricDate;
        private final Double avgBpm;
        private final Double avgReadinessScore;
        private final Double steps;
        private final Integer sampleCount;

        public DailyMetricRow(Integer employeeId, String metricDate, Double avgBpm, Double avgReadinessScore, Double steps, Integer sampleCount) {
            this.employeeId = employeeId;
            this.metricDate = metricDate;
            this.avgBpm = avgBpm;
            this.avgReadinessScore = avgReadinessScore;
            this.steps = steps;
            this.sampleCount = sampleCount;
        }

        public Integer getEmployeeId() {
            return employeeId;
        }

        public String getMetricDate() {
            return metricDate;
        }

        public Double getAvgBpm() {
            return avgBpm;
        }

        public Double getAvgReadinessScore() {
            return avgReadinessScore;
        }

        public Double getSteps() {
            return steps;
        }

        public Integer getSampleCount() {
            return sampleCount;
        }
    }

    public static class MetricRow {
        private final Integer id;
        private final Integer employeeId;
        private final Double bpm;
        private final Integer readinessScore;
        private final Integer steps;
        private final String recordedAt;

        public MetricRow(Integer id, Integer employeeId, Double bpm, Integer readinessScore, Integer steps, String recordedAt) {
            this.id = id;
            this.employeeId = employeeId;
            this.bpm = bpm;
            this.readinessScore = readinessScore;
            this.steps = steps;
            this.recordedAt = recordedAt;
        }

        public Integer getId() {
            return id;
        }

        public Integer getEmployeeId() {
            return employeeId;
        }

        public Double getBpm() {
            return bpm;
        }

        public Integer getReadinessScore() {
            return readinessScore;
        }

        public Integer getSteps() {
            return steps;
        }

        public String getRecordedAt() {
            return recordedAt;
        }
    }
}
