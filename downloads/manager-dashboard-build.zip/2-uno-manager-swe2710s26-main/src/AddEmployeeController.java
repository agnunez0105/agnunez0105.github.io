import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.regex.Pattern;

public class AddEmployeeController {

    private static final Pattern NAME_PATTERN = Pattern.compile("^[A-Za-z\\- ]{1,30}$");
    private static final Pattern EMPLOYEE_ID_PATTERN = Pattern.compile("^\\d{2}$");

    @FXML
    private TextField nameField;

    @FXML
    private TextField idField;

    private MainDashboardController mainController;
    private Scene mainScene;

    public void setMainController(MainDashboardController controller) {
        this.mainController = controller;
    }

    public void setMainScene(Scene scene) {
        this.mainScene = scene;
    }

    @FXML
    private void handleSave() {
        String name = nameField.getText() == null ? "" : nameField.getText().trim();
        String id = idField.getText() == null ? "" : idField.getText().trim();

        EmployeeDAO dao = new EmployeeDAO();

        String nameValidationError = validateEmployeeName(name);
        if (nameValidationError != null) {
            showValidationError(nameValidationError);
            return;
        }

        String idValidationError = validateEmployeeId(id, dao);
        if (idValidationError != null) {
            showValidationError(idValidationError);
            return;
        }

        int parsedId = Integer.parseInt(id);

        new Thread(() -> {
            dao.addEmployee(name, parsedId);

            Platform.runLater(() -> {
                if (mainController != null) {
                    mainController.loadDatabaseData();
                }

                returnToMainWindow();
            });
        }).start();
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        returnToMainWindow(event);
    }

    @FXML
    public void handleSwitchToMainWindow(ActionEvent event) {
        returnToMainWindow(event);
    }

    private void returnToMainWindow() {
        Stage stage = (Stage) nameField.getScene().getWindow();

        if (mainScene != null) {
            AccessibilityManager.applySettings(mainScene);
            stage.setScene(mainScene);
        } else {
            stage.close();
        }
    }

    private void returnToMainWindow(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        if (mainScene != null) {
            AccessibilityManager.applySettings(mainScene);
            stage.setScene(mainScene);
        } else {
            stage.close();
        }
    }

    private String validateEmployeeName(String name) {
        if (name.isBlank()) {
            return "Employee name is required.";
        }

        if (name.length() > 30) {
            return "Employee name must be 30 characters or fewer.";
        }

        if (!NAME_PATTERN.matcher(name).matches()) {
            return "Employee name can only contain letters, spaces, and hyphens.";
        }

        return null;
    }

    private String validateEmployeeId(String idText, EmployeeDAO dao) {
        if (!EMPLOYEE_ID_PATTERN.matcher(idText).matches()) {
            return "Employee ID must be exactly 2 digits.";
        }

        int parsedId = Integer.parseInt(idText);

        if (dao.employeeExists(parsedId)) {
            return "Employee ID is already in use. Enter a different 2-digit ID.";
        }

        return null;
    }

    private void showValidationError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Invalid Employee Input");
        alert.setHeaderText("Please fix the employee information.");
        alert.setContentText(message);
        alert.showAndWait();
    }
}