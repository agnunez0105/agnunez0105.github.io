import java.time.LocalDate;

public class DailyRecord {

    private final LocalDate date;
    private final int readinessScore;
    private final int dailyAvgBpm;
    private final int steps;

    public DailyRecord(LocalDate date, int readinessScore, int dailyAvgBpm, int steps) {
        this.date = date;
        this.readinessScore = readinessScore;
        this.dailyAvgBpm = dailyAvgBpm;
        this.steps = steps;
    }

    public LocalDate getDate()     { return date; }
    public int getReadinessScore() { return readinessScore; }
    public int getDailyAvgBpm()    { return dailyAvgBpm; }
    public int getSteps()          { return steps; }
}