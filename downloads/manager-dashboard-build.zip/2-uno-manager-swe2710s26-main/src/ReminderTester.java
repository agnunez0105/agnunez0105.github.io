import MQTTServer.ManagerClient;

import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Simulates break scheduling with fast time (for testing only)
 */
public class ReminderTester {

    public static void main(String[] args) {

        try {
            System.out.println("=== TIME BASED BREAK TEST START ===");

            ManagerClient manager = new ManagerClient("tcp://localhost:1883");

            String watchId = "12";

            int cadenceSeconds = 3; // FAST TEST (instead of minutes)

            LocalTime start = LocalTime.now().plusSeconds(2);
            LocalTime end = LocalTime.now().plusSeconds(15);

            System.out.println("Start: " + start);
            System.out.println("End: " + end);

            Timer timer = new Timer();

            long delay = 2000; // 2 seconds

            timer.scheduleAtFixedRate(new TimerTask() {

                @Override
                public void run() {

                    LocalTime now = LocalTime.now();

                    if (now.isAfter(end)) {
                        System.out.println("TEST END REACHED");
                        timer.cancel();
                        return;
                    }

                    try {
                        System.out.println("[TEST] Sending break to watch " + watchId);
                        manager.sendBreakCommand(watchId, 5);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            }, delay, cadenceSeconds * 1000L);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}