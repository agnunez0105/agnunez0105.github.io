/*
 ** Course: CSC 1110A
 ** Fall 2024
 ** Assignment:
 ** Name : Joshua Schelonka
 ** Date Created:
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AlertList {

    /**
     * Shared ObservableList that stores all BPM alerts in the system.
     * ObservableList is used so JavaFX UI components (such as ListView)
     * automatically update when the list changes.
     */
    private static final ObservableList<BPM_Alert> alerts =
            FXCollections.observableArrayList();

    /**
     * Adds a new BPM_Alert to the global alert list.
     *
     * @param alert the BPM_Alert object to be stored
     */
    public static void addAlert(BPM_Alert alert) {
        alerts.add(alert);
    }

    /**
     * Returns the full list of stored alerts.
     * This allows UI controllers to bind directly to the data source.
     *
     * @return ObservableList containing all BPM_Alert objects
     */
    public static ObservableList<BPM_Alert> getAlerts() {
        return alerts;
    }

    /**
     * Clears all stored alerts from the system
     */
    public static void clear() {
        alerts.clear();
    }
}