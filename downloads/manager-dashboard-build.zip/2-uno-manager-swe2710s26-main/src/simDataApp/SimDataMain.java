package simDataApp;

public class SimDataMain {
    public static void main(String[] args) {
        try {
            SimulatedDataService sim = new SimulatedDataService();
            sim.start();
        } catch (Exception e) {
            System.out.println("Error with simulated data: " + e.getMessage());;
        }
    }
}
