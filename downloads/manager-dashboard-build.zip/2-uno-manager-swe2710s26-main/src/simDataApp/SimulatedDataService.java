package simDataApp;

import MQTTServer.WatchClient;
import javafx.scene.control.Alert;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class SimulatedDataService {

    private final ScheduledExecutorService scheduler;
    private final Random random;
    private final static String broker = "tcp://localhost:1883";

    // At least 5 watches (you can scale this easily)
    private final List<WatchClient> watches = generateEmployees();

    private List<WatchClient> generateEmployees() throws Exception {
        WatchClient watch1 = new WatchClient(broker, "1");
        watch1.start();
        WatchClient watch2 = new WatchClient(broker, "2");
        watch2.start();
        WatchClient watch3 = new WatchClient(broker, "3");
        watch3.start();
        WatchClient watch4 = new WatchClient(broker, "4");
        watch4.start();
        WatchClient watch5 = new WatchClient(broker, "5");
        watch5.start();
        return Arrays.asList(watch1, watch2, watch3, watch4, watch5);
    }

    // Callback to send messages (MQTT publish or UI hook)
    //private final ManagerClient messageConsumer;

    //took out parameter ManagerClient messageConsumer so runs as its own app
    public SimulatedDataService() throws Exception {
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
        this.random = new Random();
//        this.messageConsumer = messageConsumer;
//        this.messageConsumer.start();
    }

    public List<WatchClient> getWatches() {
        return watches;
    }

    public void clearEmployees(){
        watches.clear();
    }

    public boolean addEmployee(WatchClient watchClient) {
        return watches.add(watchClient);
    }

//    public ManagerClient getMessageConsumer() {
//        return messageConsumer;
//    }

    /**
     * Start simulation (updates every 1–5 seconds randomly)
     */
    public void start() {
        sendFirstPayload();
        scheduleNextRun();
    }

    private void scheduleNextRun() {
        int delay = 1 + random.nextInt(5); // 1–5 seconds

        scheduler.schedule(() -> {
            try {
                generateAndSendData();
            } catch (Exception e) {
                System.out.println(e.getMessage());
                throw new RuntimeException(e);
            }
            scheduleNextRun(); // reschedule recursively
        }, delay, TimeUnit.SECONDS);
    }

    /**
     * Stop simulation safely
     */
    public void stop() {
        scheduler.shutdownNow();
    }

    /**
     * Generate data for all watches
     */
    private void generateAndSendData() throws Exception {
        for (WatchClient employee : watches) {
            Map<String, Object> payload = generatePayload(employee.getWatchId());
            if(random.nextInt(25) == 1) {
                Map<String, Object> data = generateHighImpactAlertPayload("12", watches.get(0).getWatchId());
                watches.get(0).sendAlert(data);
            }
            employee.sendData(payload);
        }
    }

    private void sendFirstPayload(){
        try {
            Map<String, Object> payload = generateFirstPayload("12", watches.get(0).getWatchId());
            watches.get(0).sendEmployee(payload);
            payload = generateFirstPayload("4", watches.get(1).getWatchId());
            watches.get(1).sendEmployee(payload);
            payload = generateFirstPayload("35", watches.get(2).getWatchId());
            watches.get(2).sendEmployee(payload);
            payload = generateFirstPayload("72", watches.get(3).getWatchId());
            watches.get(3).sendEmployee(payload);
            payload = generateFirstPayload("27", watches.get(4).getWatchId());
            watches.get(4).sendEmployee(payload);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new RuntimeException(e);
        }

    }

    private Map<String, Object> generateFirstPayload(String employeeId, String watchId) {
        Map<String, Object> data = new HashMap<>();

        data.put("timestamp", System.currentTimeMillis());
        data.put("employeeId", employeeId);
        data.put("watchId", watchId);
        return data;
    }

    private Map<String, Object> generateHighImpactAlertPayload(String employeeId, String watchId) {
        Map<String, Object> data = new HashMap<>();

        data.put("timestamp", System.currentTimeMillis());
        data.put("employeeId", employeeId);
        data.put("watchId", watchId);
        data.put("highImpactLength", 10);
        data.put("priority", "high priority");
        data.put("message", "High impact activity detected for employee " + employeeId);
        data.put("bpm", 0);
        return data;
    }

    /**
     * Generate realistic + sometimes null data
     */
    private Map<String, Object> generatePayload(String watchID) {
        Map<String, Object> data = new HashMap<>();

        data.put("timestamp", System.currentTimeMillis());
        data.put("watchId", watchID);
        // Randomly inject nulls (~15% chance)
        data.put("heartRate", maybeNull(generateHeartRate()));
        data.put("steps", maybeNull(generateSteps()));
        data.put("readiness", maybeNull(generateReadiness()));

        return data;
    }

    private Object maybeNull(Object value) {
        return random.nextDouble() < 0.15 ? null : value;
    }


    /**
     * Realistic physiological values
     */
    private int generateHeartRate() {
        return 40 + random.nextInt(141); // 40–180 BPM
    }

    private int generateSteps() {
        return random.nextInt(20); // steps per interval (small increments)
    }

    private int generateReadiness() {
        return random.nextInt(101); // 0–100
    }
}