/*
 * Course: SWE2710 - Software Tools & Process
 * Term: Spring 2026
 * Uno- Manager Project Tests
 * Author: Arianna Nunez
 */

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.List;

/**
 * -----------------------------------------------------------------------------
 * Unit tests for verifying that CsvExporter correctly writes worker data
 * content into the generated CSV file. Ensures that exported files contain
 * the expected headers and properly formatted worker data.
 *
 * @author Arianna Nunez
 * @version 1.0
 * @since 02/21/26
 * -----------------------------------------------------------------------------
 */
public final class CsvExporterContentTest {

    @Test
    public void testCsvContainsExpectedData() throws IOException {

        final List<Worker> workers = List.of(
                new Worker("Alice Smith", "1", "Watch-001", 85, 72, 10000),
                new Worker("Bob Jones", "2", "Watch-002", 90, 68, 9000)
        );

        final LocalDate startDate = LocalDate.of(2026, 1, 1);
        final LocalDate endDate = LocalDate.of(2026, 12, 31);

        final File csvFile = CsvExporter.exportToCsv(
                workers,
                startDate,
                endDate,
                true,
                true,
                true
        );

        Assertions.assertNotNull(csvFile);
        Assertions.assertTrue(csvFile.exists());

        final String content = Files.readString(csvFile.toPath());

        Assertions.assertTrue(
                content.contains("Start Date,End Date,Employee,Worker ID,Watch ID,Readiness Score,Daily Avg BPM,Steps")
        );

        Assertions.assertTrue(content.contains("2026-01-01"));
        Assertions.assertTrue(content.contains("2026-12-31"));

        Assertions.assertTrue(content.contains("Alice Smith"));
        Assertions.assertTrue(content.contains("Bob Jones"));

        Assertions.assertTrue(content.contains("Watch-001"));
        Assertions.assertTrue(content.contains("Watch-002"));

        Assertions.assertTrue(content.contains("85"));
        Assertions.assertTrue(content.contains("72"));
        Assertions.assertTrue(content.contains("10000"));

        Assertions.assertTrue(content.contains("90"));
        Assertions.assertTrue(content.contains("68"));
        Assertions.assertTrue(content.contains("9000"));
    }
}