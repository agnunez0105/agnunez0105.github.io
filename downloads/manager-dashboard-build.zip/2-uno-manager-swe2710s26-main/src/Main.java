/**
 * -----------------------------------------------------------------------------
 * Main class that loads the MainDashboard.fxml file and configures the stage.
 *
 * @author John Balasbas, Zoe Kirkman
 * @version 1.0
 * @since 02/23/26
 * -----------------------------------------------------------------------------
 */


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;


public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            DatabaseManager.initializeDatabase();

            // Load the FXML file associated with MainDashboardController
            FXMLLoader loader = new FXMLLoader(getClass().getResource("MainDashboard.fxml"));
            Parent root = loader.load();

            //testAlerts();
            // Set the scene
            Scene scene = new Scene(root);
            ((MainDashboardController)loader.getController()).setMainScene(scene);
            // Configure the stage/window
            primaryStage.setTitle("Main Dashboard");
            primaryStage.setScene(scene);
            primaryStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error loading MainDashboard.fxml. Check the file path.");
        }
    }

//    private void testAlerts() {
//
//        System.out.println("=== ALERT TEST START ===");
//
//        int employeeId = 1;
//
//        // simulate baseline data first (so baseline isn't 0)
//        for (int i = 0; i < 10; i++) {
//            EmployeeDAO dao = new EmployeeDAO();
//            dao.recordBPM(employeeId, 70 + i); // normal BPMs
//        }
//
//        // now trigger alerts
//        int[] testBPMs = {85, 90, 120, 160, 200};
//
//        for (int bpm : testBPMs) {
//
//            System.out.println("Sending BPM: " + bpm);
//
//            Baseline.checkForAlert(employeeId, bpm);
//
//            System.out.println("AlertList size: " +
//                    AlertList.getAlerts().size());
//        }
//
//        System.out.println("=== ALERT TEST END ===");
//    }
}