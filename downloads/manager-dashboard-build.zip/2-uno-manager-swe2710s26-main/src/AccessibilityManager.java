import javafx.scene.Parent;
import javafx.scene.Scene;

public final class AccessibilityManager {

    private static boolean redGreenModeEnabled = false;
    private static boolean blueYellowModeEnabled = false;
    private static boolean largeTextModeEnabled = false;

    private AccessibilityManager() {
    }

    public static void applySettings(Scene scene) {
        if (scene == null || scene.getRoot() == null) {
            return;
        }

        addStylesheetIfMissing(scene);

        Parent root = scene.getRoot();

        root.getStyleClass().removeAll(
                "red-green-mode",
                "blue-yellow-mode",
                "large-text-mode"
        );

        root.setStyle("-fx-font-size: 13px;");

        if (redGreenModeEnabled) {
            root.getStyleClass().add("red-green-mode");
        }

        if (blueYellowModeEnabled) {
            root.getStyleClass().add("blue-yellow-mode");
        }

        if (largeTextModeEnabled) {
            root.setStyle("");
            root.getStyleClass().add("large-text-mode");
        }

        root.applyCss();
        root.layout();
    }

    private static void addStylesheetIfMissing(Scene scene) {
        String stylesheet = AccessibilityManager.class
                .getResource("styles.css")
                .toExternalForm();

        if (!scene.getStylesheets().contains(stylesheet)) {
            scene.getStylesheets().add(stylesheet);
        }
    }

    public static void setDefaultMode() {
        redGreenModeEnabled = false;
        blueYellowModeEnabled = false;
    }

    public static void setRedGreenMode() {
        redGreenModeEnabled = true;
        blueYellowModeEnabled = false;
    }

    public static void setBlueYellowMode() {
        redGreenModeEnabled = false;
        blueYellowModeEnabled = true;
    }

    public static void setLargeTextMode(boolean enabled) {
        largeTextModeEnabled = enabled;
    }

    public static void resetAll() {
        redGreenModeEnabled = false;
        blueYellowModeEnabled = false;
        largeTextModeEnabled = false;
    }

    public static boolean isRedGreenModeEnabled() {
        return redGreenModeEnabled;
    }

    public static boolean isBlueYellowModeEnabled() {
        return blueYellowModeEnabled;
    }

    public static boolean isLargeTextModeEnabled() {
        return largeTextModeEnabled;
    }
}