/*
 * Course: SWE2710 - Software Tools & Process
 * Term: Spring 2026
 * Uno- Manager Project Tests
 * Author: Arianna Nunez
 */

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

/**
 * -----------------------------------------------------------------------------
 * Unit tests for validating CsvExporter behavior when no worker data is
 * available.
 * -----------------------------------------------------------------------------
 */
public final class CsvExporterEmptyDataTest {

    private static final String FILE_NAME = "health_data.csv";

    @BeforeEach
    public void setUp() {
        File file = new File(System.getProperty("user.home")
                + File.separator + "Downloads"
                + File.separator + FILE_NAME);

        if (file.exists()) {
            boolean deleted = file.delete();
            Assertions.assertTrue(deleted);
        }
    }

    @Test
    public void testNoCsvGeneratedWhenNoWorkers() throws Exception {
        List<Worker> workers = List.of();

        File file = CsvExporter.exportToCsv(
                workers,
                LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 12, 31),
                true,
                true,
                true
        );

        Assertions.assertNotNull(file);
        Assertions.assertTrue(file.exists());
    }
}