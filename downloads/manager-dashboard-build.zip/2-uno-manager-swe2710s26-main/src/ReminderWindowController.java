import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import MQTTServer.ManagerClient;
import javafx.stage.Stage;

import java.time.LocalTime;
import java.util.Timer;
import java.util.TimerTask;

public class ReminderWindowController {

    @FXML private TextField watchIdField;
    @FXML private TextField breakDurationField;
    @FXML private TextField startTimeField;

    private ObservableList<Worker> workers;
    private ManagerClient manager;

    private Scene mainScene;

    public void setMainScene(Scene scene) {
        this.mainScene = scene;
    }

    @FXML
    public void handleSwitchToMainWindow(ActionEvent event) {
        if (mainScene == null) {
            System.out.println("Main scene was not set!");
            return;
        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(mainScene);
        stage.show();
    }
    public void setManager(ManagerClient manager) {
        this.manager = manager;
    }

    @FXML
    public void handleScheduleBreak() {

        try {
            String target = watchIdField.getText().trim();
            String durationText = breakDurationField.getText().trim();
            String startText = startTimeField.getText().trim();

            if (!validateInputs(target, durationText, startText)) {
                return;
            }

            int duration = Integer.parseInt(durationText);
            LocalTime startTime = LocalTime.parse(startText);
            String watchId = resolveWatchId(target);

            if (watchId == null) {
                showError("Watch not found","No matching watch found for: " + target);
                return;
            }
            Worker worker = findWorkerByWatchID(watchId);

            if (worker == null) {
                showError("Worker Error", "No worker found for watch ID: " + watchId);
                return;
            }


            System.out.println("Scheduled break for: " + target);

            Timer timer = new Timer(true);

            timer.scheduleAtFixedRate(new TimerTask() {


                @Override
                public void run() {

                    LocalTime now = LocalTime.now();

                    // wait until start time is reached
                    if (!now.isBefore(startTime)) {

                        try {


                            // ------------------------------------
                            // 1. SEND MQTT BREAK COMMAND
                            // ------------------------------------

                            manager.sendBreakCommand(watchId, duration);

                            System.out.println("One break sent to id " + watchId);

                            // ------------------------------------
                            // 2. PUSH TO ALERT SYSTEM (UI UPDATE)
                            // ------------------------------------
                            String time = java.time.LocalDateTime.now()
                                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));



                            int employeeId = Integer.parseInt(worker.getWorkerId());

                            BPM_Alert alert = new BPM_Alert(
                                    employeeId,
                                    "Break Sent (" + duration + " min)",
                                    "Low Priority",
                                    time,
                                    0
                            );

                            AlertList.addAlert(alert);

                            System.out.println("Break alert added to AlertList");

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        timer.cancel(); //
                    }
                }

            }, 0, 1000);

        } catch (Exception e) {
            System.out.println("Invalid input (check ID, time, duration)");
            e.printStackTrace();
        }
    }

    /**
     * Allows ID OR name lookup
     */
    private String resolveWatchId(String input) {
        for (Worker w : workers) {
            if (w.getWorkerId().equals(input) ||
                    w.getEmployeeName().equalsIgnoreCase(input)) {
                return w.getWatchId();
            }
        }
        return null;
    }




    public void setWorkers(ObservableList<Worker> workers) {
        this.workers = workers;
    }
    private Worker findWorkerByWatchID(String watchId) {
        if (workers == null) return null;

        for (Worker w : workers) {
            if (w.getWatchId() != null && w.getWatchId().equals(watchId)) {
                return w;
            }
        }
        return null;
    }

    private void showError(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    private boolean validateInputs(String target, String durationText, String timeText) {

        // -------------------------
        // 1. Watch ID or Name check
        // -------------------------
        if (target == null || target.isBlank()) {
            showError("Input Error", "Watch ID or Name cannot be empty.");
            return false;
        }

        // -------------------------
        // 2. Duration check (minutes)
        // -------------------------
        int duration;
        try {
            duration = Integer.parseInt(durationText);
            if (duration <= 0 || duration > 240) {
                showError("Input Error", "Break duration must be between 1 and 240 minutes.");
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Input Error", "Break duration must be a valid number.");
            return false;
        }

        // -------------------------
        // 3. Time format check (HH:mm)
        // -------------------------
        try {
            java.time.LocalTime.parse(timeText);
        } catch (Exception e) {
            showError("Input Error", "Start time must be in HH:mm format (24-hour time).");
            return false;
        }

        return true;
    }

}