import java.util.ArrayList;
import java.util.List;

public class WorkerList {




    private List<Worker> workers;

    public WorkerList(){
        workers = new ArrayList<>();
    }

    public WorkerList(List<Worker> work) {
        workers = work;
    }



    public void addWorker(Worker worker){
        if(worker == null)
            throw new IllegalArgumentException("Worker is null");
        workers.add(worker);
    }

    public void removeWorker(Worker worker){

        workers.remove(worker);
    }

    public List<Worker> getWorkers(){
        return workers;
    }

    private void endDay() {
        for (Worker w: workers) {
            w.endDay();
        }
    }
}
