package MQTTServer;


import org.eclipse.paho.client.mqttv3.IMqttMessageListener;

import java.util.HashMap;
import java.util.Map;

/**
 * -----------------------------------------------------------------------------
 * This class creates an object for a manager client that can send and receive
 * messages to and from the watch client.
 *
 * @author Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class ManagerClient {
    private MQTTService service;

    public ManagerClient(String broker) throws Exception {
        service = new MQTTService("tcp://localhost:1883", "manager");
    }

    // i dont think this is necessary because in start we start subscribing to all types of messages
    public void subscribeToWatches(IMqttMessageListener listener) throws Exception {
        service.subscribe("watch/+/#", listener);
    }

    // Start listening to all watches
    public void start() throws Exception {
        ManagerListener listener = new ManagerListener();

        System.out.println("[Manager] Listening to all watches...");
    }

    // Send a break command
    public void sendBreakCommand(String watchId, int duration) throws Exception {
        Message breakMsg = new Message(
                "break",
                "manager",
                watchId,
                "Take a " + duration + "-minute break"
        );

        service.publish("watch/" + watchId + "/commands", breakMsg.toJson());
        System.out.println("[Manager] Break command sent to watch " + watchId);
    }

    // Send a generic message
    public void sendMessage(String watchId, String type, Object payload) throws Exception {
        Message msg = new Message(type, "manager", watchId, payload);
        service.publish("watch/" + watchId + "/commands", msg.toJson());
    }

    //send an error for invalid id
    public void sendConnectionError(String watchId, String type, Object payload) throws Exception{
        Message error = new Message(type,  "manager", watchId, payload);
        service.publish("watch/" + watchId + "/error", error.toJson());
    }

    public Map<String, Object> getErrorPayload(String employeeId){
        Map<String, Object> error = new HashMap<>();

        error.put("employeeId", employeeId);
        error.put("error message", "Not a valid employee id, ask manager to add you to dashboard");
        return error;
    }
}

