package MQTTServer;

import org.eclipse.paho.client.mqttv3.*;

/**
 * -----------------------------------------------------------------------------
 * This class is a wrapper class for the MQTTClient class so it is easier for
 * the rest of the project to connect to MQTT services
 *
 * @author Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class MQTTService {

    private MqttClient client;

    public MQTTService(String broker, String clientId) throws Exception {
        client = new MqttClient(broker, clientId);
        client.connect();
    }

    public void subscribe(String topic, IMqttMessageListener listener) throws Exception {
        client.subscribe(topic, listener);
    }

    public void publish(String topic, String payload) throws Exception {
        MqttMessage message = new MqttMessage(payload.getBytes());
        client.publish(topic, message);
    }

    public MqttClient getClient() {
        return client;
    }
}