package MQTTServer;

import org.eclipse.paho.client.mqttv3.*;

/**
 * -----------------------------------------------------------------------------
 * This class creates a listener for the WatchClient so that they can
 * receive all messages they are sent.
 *
 * @author Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class WatchListener implements IMqttMessageListener {

    private MQTTService service;
    private String watchId;

    public WatchListener(MQTTService service, String watchId) {
        this.service = service;
        this.watchId = watchId;
    }

    @Override
    public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
        String payload = new String(mqttMessage.getPayload());
        Message message = Message.fromJson(payload);

        System.out.println("[Watch " + watchId + "] Received " + message.getTopic() +
                " from " + message.getSender() + ": " + message.getPayload());

        // Example: automatically accept breaks
        if(message.getTopic().equals("break")) {
            service.publish("watch/" + watchId + "/status",
                    new Message("status", watchId, "manager", "accepted").toJson());
            System.out.println("[Watch " + watchId + "] Break accepted");
        }
    }
}