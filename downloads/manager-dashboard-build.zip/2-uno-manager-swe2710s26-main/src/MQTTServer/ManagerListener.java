package MQTTServer;

import org.eclipse.paho.client.mqttv3.*;

/**
 * -----------------------------------------------------------------------------
 * This class creates a listener for the ManagerClients so that they can
 * receive all messages they are sent.
 *
 * @author Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class ManagerListener implements IMqttMessageListener {

    @Override
    public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
        String payload = new String(mqttMessage.getPayload());
        Message message = Message.fromJson(payload);

        System.out.println("[Manager] Received " + message.getTopic() +
                " from " + message.getSender() +
                " to " + message.getTo() +
                ": " + message.getPayload());
    }
}