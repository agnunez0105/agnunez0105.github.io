package MQTTServer;

/**
 * -----------------------------------------------------------------------------
 * Represents a wearable device assigned to a worker that publishes sensor
 * data such as heart rate or alerts to the MQTT broker.
 *
 * @author Arianna Nunez, Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class Watch {

    private String deviceId;

    public Watch(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceId() {
        return deviceId;
    }
}
