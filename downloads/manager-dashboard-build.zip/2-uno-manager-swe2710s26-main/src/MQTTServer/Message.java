package MQTTServer;

import com.google.gson.Gson;

public class Message {

    private String topic;       // break, health_alert, data, etc.
    private String from;       // sender ID (watch ID or "manager")
    private String to;         // receiver ID ("manager" or watch ID)
    private Object payload;    // the actual content, can be a Map, number, string, etc.

    private static final Gson gson = new Gson();

    // Constructor
    public Message(String type, String from, String to, Object payload) {
        this.topic = type;
        this.from = from;
        this.to = to;
        this.payload = payload;
    }

    // Convert Message object to JSON string for sending
    public String toJson() {
        return gson.toJson(this);
    }

    // Parse JSON string back into Message object
    public static Message fromJson(String json) {
        return gson.fromJson(json, Message.class);
    }

    // Getters
    public String getTopic() { return topic; }
    public String getSender() { return from; }
    public String getTo() { return to; }
    public Object getPayload() { return payload; }

    @Override
    public String toString() {
        return toJson();
    }
}