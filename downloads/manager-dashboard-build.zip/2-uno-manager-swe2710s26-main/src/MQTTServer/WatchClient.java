package MQTTServer;

/**
 * -----------------------------------------------------------------------------
 * This class creates an object for a watch client that can send and receive
 * messages to and from the manager client.
 *
 * @author Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class WatchClient {

    private MQTTService service;
    private String watchId;

    public WatchClient(String broker, String watchId) throws Exception {
        this.watchId = watchId;
        this.service = new MQTTService(broker, "watch-" + watchId);
    }

    // Start listening to commands from manager
    public void start() throws Exception {
        WatchListener listener = new WatchListener(service, watchId);
        service.subscribe("watch/" + watchId + "/#", listener);

        System.out.println("[Watch " + watchId + "] Listening for commands...");
    }

    // Send connection message to manager
    //payload is the employee id number
    public void sendEmployee(Object payload) throws Exception{
        Message employee = new Message("employee", watchId, "manager", payload);
        service.publish("watch/" + watchId + "/employee", employee.toJson());
        System.out.println("[Watch " + watchId + "] Sending employee: " + payload);
    }

    // Send health data to manager
    public void sendData(Object payload) throws Exception {
        Message data = new Message("data", watchId, "manager", payload);
        service.publish("watch/" + watchId + "/data", data.toJson());
        System.out.println("[Watch " + watchId + "] Health data sent:" + payload);
    }

    // Send high impact activity duration
    public void sendHighImpactAcivityDuration(Object payload) throws Exception {
        Message data = new Message("alert", watchId, "manager", payload);
        service.publish("watch/" + watchId + "/alert", data.toJson());
        System.out.println("[Watch " + watchId + "] High impact duration sent:" + payload);
    }

    // Send health alert to manager
    public void sendAlert(Object payload) throws Exception {
        Message alert = new Message("alert", watchId, "manager", payload);
        service.publish("watch/" + watchId + "/alert", alert.toJson());
        System.out.println("[Watch " + watchId + "] Health alert sent:" + payload);
    }

    // Send status response to manager
    public void sendStatus(String status) throws Exception {
        Message statusMsg = new Message("status", watchId, "manager", status);
        service.publish("watch/" + watchId + "/status", statusMsg.toJson());
        System.out.println("[Watch " + watchId + "] Status sent: " + status);
    }

    //send heart rate to manager
    public void sendHeartRate(int heartRate) throws Exception {
        Message heartRateUpdate = new Message("heart_rate_data", watchId, "manager", Integer.toString(heartRate));
        service.publish("watch/" + watchId + "/heart_rate_data",  heartRateUpdate.toJson());
        System.out.println("[Watch " + watchId + "] Heart rate updated: " + heartRate);

    }

    public String getWatchId(){
        return watchId;
    }

}