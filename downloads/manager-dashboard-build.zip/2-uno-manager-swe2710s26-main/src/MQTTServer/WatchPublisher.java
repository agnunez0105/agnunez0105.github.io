package MQTTServer;

import org.eclipse.paho.client.mqttv3.*;

public class WatchPublisher {
    public static void main(String[] args) {
        String broker = "tcp://localhost:1883";
        String clientId = "watch-001";
        String topic = "watch/data";

        try {
            MqttClient client = new MqttClient(broker, clientId);

            MqttConnectOptions options = new MqttConnectOptions();
            options.setAutomaticReconnect(true);
            options.setCleanSession(true);

            client.connect(options);
            System.out.println("Connected to MQTT broker");

            String payload = "{\"watchId\":\"001\",\"heartRate\":78,\"steps\":1540,\"readiness\":85}";
            MqttMessage message = new MqttMessage(payload.getBytes());
            message.setQos(1);

            client.publish(topic, message);
            System.out.println("Message published");

            client.disconnect();
            client.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}