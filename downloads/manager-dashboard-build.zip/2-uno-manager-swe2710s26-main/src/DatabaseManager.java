import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseManager {
    // The .db file will be created in the project root
    private static final String URL = "jdbc:sqlite:health_manager.db";

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL);
    }

    public static void initializeDatabase() {
        String createEmployeesTable = "CREATE TABLE IF NOT EXISTS employees (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL);";

        String createMetricsTable = "CREATE TABLE IF NOT EXISTS metrics (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "employee_id INTEGER," +
                "bpm REAL," +
                "readiness_score INTEGER," +
                "steps INTEGER," +
                "recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "FOREIGN KEY(employee_id) REFERENCES employees(id));";

        String createDailyMetricsTable = "CREATE TABLE IF NOT EXISTS daily_metrics (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "employee_id INTEGER NOT NULL," +
                "metric_date TEXT NOT NULL," +
                "avg_bpm REAL," +
                "avg_readiness_score REAL," +
                "steps REAL DEFAULT 0," +
                "sample_count INTEGER DEFAULT 0," +
                "updated_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
                "UNIQUE(employee_id, metric_date)," +
                "FOREIGN KEY(employee_id) REFERENCES employees(id));";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createEmployeesTable);
            stmt.execute(createMetricsTable);
            stmt.execute(createDailyMetricsTable);
            // Backward-compatible migration for old local DB files.
            stmt.execute("ALTER TABLE metrics ADD COLUMN readiness_score INTEGER");
        } catch (Exception ignored) {
        }

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("ALTER TABLE metrics ADD COLUMN steps INTEGER");
        } catch (Exception ignored) {
        }

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("ALTER TABLE daily_metrics ADD COLUMN steps REAL DEFAULT 0");
            stmt.execute("UPDATE daily_metrics SET steps = COALESCE(steps, avg_steps, 0)");
        } catch (Exception ignored) {
        }

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_metrics_employee_date ON metrics(employee_id, recorded_at)");
            stmt.execute("CREATE INDEX IF NOT EXISTS idx_daily_metrics_employee_date ON daily_metrics(employee_id, metric_date)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}