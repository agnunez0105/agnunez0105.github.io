import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    /**
     * SQLite / JDBC may return Long or Double for numeric columns; normalize to Integer or null.
     */
    private static Integer toInteger(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Integer) {
            return (Integer) value;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return null;
    }

    public List<Worker> getAllWorkers() {
        List<Worker> workers = new ArrayList<>();

        String sql = "SELECT e.id, e.name, " +
                "CAST(ROUND(dm.avg_bpm) AS INTEGER) as avg_bpm, " +
                "CAST(ROUND(dm.avg_readiness_score) AS INTEGER) as avg_readiness_score, " +
                "CAST(ROUND(dm.steps) AS INTEGER) as steps " +
                "FROM employees e " +
                "LEFT JOIN daily_metrics dm ON e.id = dm.employee_id " +
                "AND dm.metric_date = date('now', 'localtime')";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String employeeId = Integer.toString(rs.getInt("id"));
                String name = rs.getString("name");
                Integer bpm = toInteger(rs.getObject("avg_bpm"));
                Integer readiness = toInteger(rs.getObject("avg_readiness_score"));
                Integer steps = toInteger(rs.getObject("steps"));
                workers.add(new Worker(name, employeeId, "", readiness, bpm, steps));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return workers;
    }

    /**
     * Inserts the default demo roster when the database has no employees yet (matches simulated watch IDs).
     */
    public void seedDefaultEmployeesIfEmpty() {
        String countSql = "SELECT COUNT(*) FROM employees";
        try (Connection conn = DatabaseManager.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(countSql)) {
            if (rs.next() && rs.getInt(1) > 0) {
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        String insert = "INSERT INTO employees(id, name) VALUES(?, ?)";
        int[] ids = {12, 4, 35, 72, 27};
        String[] names = {"Josh", "John", "Ari", "Jan", "Zoe"};
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(insert)) {
            for (int i = 0; i < ids.length; i++) {
                pstmt.setInt(1, ids[i]);
                pstmt.setString(2, names[i]);
                pstmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Adds a new employee to the database.
     */
    public void addEmployee(String name) {
        String sql = "INSERT INTO employees(name) VALUES(?)";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.executeUpdate();
            System.out.println("Employee " + name + " added successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addEmployee(String name, Integer id) {
        String sqlWithId = "INSERT INTO employees(id, name) VALUES(?, ?)";
        if (id == null) {
            addEmployee(name);
            return;
        }

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sqlWithId)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.executeUpdate();
            System.out.println("Employee " + name + " added with id " + id + " successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean employeeExists(int employeeId) {
        String sql = "SELECT 1 FROM employees WHERE id = ? LIMIT 1";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employeeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Records an incoming data sample and updates this employee's daily aggregates.
     */
    public void recordMetricSample(int employeeId, Integer bpm, Integer readinessScore, Integer steps) {
        String rawSql = "INSERT INTO metrics(employee_id, bpm, readiness_score, steps) VALUES(?, ?, ?, ?)";
        String upsertDailySql = "INSERT INTO daily_metrics(employee_id, metric_date, avg_bpm, avg_readiness_score, steps, sample_count, updated_at) " +
                "VALUES (?, date('now', 'localtime'), ?, ?, ?, 1, CURRENT_TIMESTAMP) " +
                "ON CONFLICT(employee_id, metric_date) DO UPDATE SET " +
                "avg_bpm = ((daily_metrics.avg_bpm * daily_metrics.sample_count) + excluded.avg_bpm) / (daily_metrics.sample_count + 1), " +
                "avg_readiness_score = ((daily_metrics.avg_readiness_score * daily_metrics.sample_count) + excluded.avg_readiness_score) / (daily_metrics.sample_count + 1), " +
                "steps = COALESCE(daily_metrics.steps, 0) + COALESCE(excluded.steps, 0), " +
                "sample_count = daily_metrics.sample_count + 1, " +
                "updated_at = CURRENT_TIMESTAMP";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement rawStmt = conn.prepareStatement(rawSql);
             PreparedStatement dailyStmt = conn.prepareStatement(upsertDailySql)) {
            conn.setAutoCommit(false);

            rawStmt.setInt(1, employeeId);
            if (bpm == null) {
                rawStmt.setNull(2, java.sql.Types.REAL);
            } else {
                rawStmt.setDouble(2, bpm);
            }
            if (readinessScore == null) {
                rawStmt.setNull(3, java.sql.Types.INTEGER);
            } else {
                rawStmt.setInt(3, readinessScore);
            }
            if (steps == null) {
                rawStmt.setNull(4, java.sql.Types.INTEGER);
            } else {
                rawStmt.setInt(4, steps);
            }
            rawStmt.executeUpdate();

            dailyStmt.setInt(1, employeeId);
            dailyStmt.setDouble(2, bpm == null ? 0 : bpm);
            dailyStmt.setDouble(3, readinessScore == null ? 0 : readinessScore);
            dailyStmt.setDouble(4, steps == null ? 0 : steps);
            dailyStmt.executeUpdate();
            conn.commit();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
