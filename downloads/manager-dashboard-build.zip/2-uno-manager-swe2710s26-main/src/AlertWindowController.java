
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.layout.*;

public class AlertWindowController {

    // ListView that displays BPM alerts in the UI
    @FXML
    private ListView<BPM_Alert> alertListView;

    // TextField used for searching/filtering alerts
    @FXML
    private TextField searchField;

    // Reference to the main application scene for navigation
    private Scene mainScene;

    /**
     * Stores filtered alerts based on search input.
     * This allows dynamic updating of the ListView display.
     */
    private FilteredList<BPM_Alert> filtered;

    /**
     * Sets the main scene so the controller can switch back to it.
     *
     * @param scene the main application scene
     */
    public void setMainScene(Scene scene) {
        this.mainScene = scene;
    }

    /**
     * Configures the search filter for the alert list.
     * Filters alerts based on:
     * - employee ID
     * - message content
     * - priority level
     */
    private void setupFilter() {

        searchField.textProperty().addListener((obs, oldVal, newVal) -> {

            String lower = newVal == null ? "" : newVal.toLowerCase();

            filtered.setPredicate(alert -> {

                // Show all alerts if search field is empty
                if (lower.isEmpty()) return true;

                // Filter based on matching fields
                return alert.getMessage().toLowerCase().contains(lower)
                        || String.valueOf(alert.getEmployeeId()).contains(lower)
                        || alert.getPriority().toLowerCase().contains(lower);
            });
        });
    }

    /**
     * Handles navigation back to the main window.
     *
     * @param event button click event
     */
    @FXML
    private void handleSwitchToMainWindow(ActionEvent event) {

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene()
                .getWindow();

        if (mainScene != null) {
            stage.setScene(mainScene);
            stage.show();
        } else {
            System.out.println("Main scene is null");
        }
    }

    /**
     * Initializes the controller after FXML loading.
     * Sets up:
     * - Observable alert list binding
     * - Custom cell rendering for alerts
     * - Search filtering functionality
     */
    @FXML
    public void initialize() {

        // Wrap global alert list in a filtered list
        filtered = new FilteredList<>(AlertList.getAlerts(), p -> true);

        // Bind filtered list to ListView
        alertListView.setItems(filtered);

        // Custom display format for each alert in the list
        alertListView.setCellFactory(list -> new javafx.scene.control.ListCell<>() {
            @Override
            protected void updateItem(BPM_Alert alert, boolean empty) {
                super.updateItem(alert, empty);

                if (empty || alert == null) {
                    setText(null);
                    setGraphic(null);
                    setStyle("-fx-padding: 0; -fx-background-color: transparent");
                    return;
                }
                // --- Badge (type) ---
                Label typeBadge = new Label(alert.getPriority());
                typeBadge.getStyleClass().addAll("alert-badge", getBadgeStyle(alert.getPriority()));

                // --- Time ---
                Label timeLabel = new Label(alert.getTime());
                timeLabel.getStyleClass().add("alert-time");

                // --- Top row ---
                HBox topRow = new HBox(8, typeBadge, new Region(), timeLabel);
                HBox.setHgrow(topRow.getChildren().get(1), Priority.ALWAYS);
                topRow.setAlignment(Pos.CENTER_LEFT);

                // --- Employee row ---
                Label nameLabel = new Label("Employee " + alert.getEmployeeId());
                nameLabel.getStyleClass().add("alert-name");
                Label bpmLabel = new Label("BPM: " + alert.getBpm());
                bpmLabel.getStyleClass().add("alert-id");
                HBox employeeRow = new HBox(6, nameLabel, bpmLabel);
                employeeRow.setAlignment(Pos.CENTER_LEFT);

                // ---- description -----
                Label description = new Label(alert.getMessage());
                description.getStyleClass().add("alert-description");
                HBox descriptionRow = new HBox(6, description);
                descriptionRow.setAlignment(Pos.CENTER_LEFT);

                // --- Priority row ---
                Label priorityLabel;
                if (alert.getPriority() != null) {
                    priorityLabel = new Label("Priority: " + alert.getPriority());
                    priorityLabel.getStyleClass().add("alert-description");
                } else {
                    priorityLabel = new Label("Priority: " + "high");
                    priorityLabel.getStyleClass().add("alert-description");
                }

                // --- Card ---
                VBox card = new VBox(6, topRow, employeeRow, priorityLabel, descriptionRow);
                card.getStyleClass().add("alert-card");

                setText(null);
                setGraphic(card);
                setStyle("-fx-padding: 0; -fx-background-color: transparent; -fx-border-color: black; -fx-border-width: 0 0 1 0;");
            }
        });

        // Activate search filtering
        setupFilter();
    }

    private String getBadgeStyle(String priority) {
        return switch (priority.toLowerCase()) {
            case "high priority"   -> "badge-health";
            case "medium priority" -> "badge-reminder";
            case "low priority"    -> "badge-taken";
            default       -> "badge-default";
        };
    }
}