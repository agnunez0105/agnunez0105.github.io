import MQTTServer.ManagerClient;
import MQTTServer.Message;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainDashboardController {

    @FXML private TableView<Worker> dashboardTable;
    @FXML private TableColumn<Worker, String> employeeCol;
    @FXML private TableColumn<Worker, Integer> readinessCol;
    @FXML private TableColumn<Worker, Integer> bpmCol;
    @FXML private TableColumn<Worker, Integer> stepsCol;

    @FXML private TextField searchField;
    @FXML private TextField minReadinessField;
    @FXML private TextField minBpmField;
    @FXML private TextField minStepsField;

    @FXML private Button accessibilityButton;

    private Scene reminderScene = null;
    private Scene exportScene = null;
    private Scene alertScene = null;
    private Scene addEmployeeScene = null;
    private Scene databaseViewScene = null;
    private Scene mainScene;

    private DatabaseViewController databaseViewController;

    private ObservableList<Worker> masterData = FXCollections.observableArrayList();
    private FilteredList<Worker> filteredData;
    private ManagerClient managerClient;
    private final EmployeeDAO employeeDAO = new EmployeeDAO();

    private Baseline baseline = new Baseline();
    private AlertWindowController alertController;

    @FXML
    public void initialize() {
        try {
            managerClient = new ManagerClient("tcp://localhost:1883");
            managerClient.start();
        } catch (Exception e) {
            System.out.println("Manager Client unable to connect to broker: " + e.getMessage());
        }

        employeeCol.setCellValueFactory(new PropertyValueFactory<>("employeeName"));
        readinessCol.setCellValueFactory(new PropertyValueFactory<>("readinessScore"));
        bpmCol.setCellValueFactory(new PropertyValueFactory<>("dailyAvgBpm"));
        stepsCol.setCellValueFactory(new PropertyValueFactory<>("steps"));

        employeeDAO.seedDefaultEmployeesIfEmpty();
        masterData.setAll(employeeDAO.getAllWorkers());

        try {
            managerClient.subscribeToWatches((topic, mqttMessage) -> {
                String json = new String(mqttMessage.getPayload());
                Message message = Message.fromJson(json);
                Platform.runLater(() -> handleIncomingMessage(message));
            });

            filteredData = new FilteredList<>(masterData, p -> true);
            setupFiltering();

            SortedList<Worker> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(dashboardTable.comparatorProperty());
            dashboardTable.setItems(sortedData);

            dashboardTable.setRowFactory(tv -> new TableRow<Worker>() {
                @Override
                protected void updateItem(Worker worker, boolean empty) {
                    super.updateItem(worker, empty);
                    if (worker == null || empty) {
                        setStyle("");
                    } else if (worker.isHasAlert()) {
                        setStyle("-fx-background-color: #ff4d4d;");
                    } else {
                        setStyle("");
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading simulated data");
        }
    }

    private void handleIncomingMessage(Message message) {
        if ("data".equals(message.getTopic())) {
            handleDataMessage(message);
        } else if ("employee".equals(message.getTopic())) {
            handleEmployeeConnectionToWatch(message);
        } else if ("alert".equals(message.getTopic())) {
            handleAlertMessage(message);
        }
    }

    private void handleAlertMessage(Message message) {
        String watchId = message.getSender();
        Object payload = message.getPayload();

        Worker worker = findWorkerByWatchID(watchId);
        if (worker == null) {
            System.out.println("Warning: Received alert for unknown watch ID: " + watchId);
            return;
        }

        String alertText = "";
        String priority = "";
        double bpm = 0;

        if (payload instanceof Map<?, ?> data) {
            String employeeId = data.get("employeeId") != null ? data.get("employeeId").toString() : worker.getWorkerId();
            priority = data.get("priority") != null ? data.get("priority").toString() : "low priority";
            bpm = data.get("bpm") != null ? ((Number) data.get("bpm")).doubleValue() : 0;
            alertText = data.get("message") != null ? data.get("message").toString()
                    : "Alert for employee " + employeeId;
            alertText = data.get("highImpactLength") != null ? alertText += " for " + data.get("highImpactLength").toString() + " minutes"
                    : alertText;
            long time = data.get("timestamp") != null ? (long) ((Number)data.get("timestamp")).longValue() : System.currentTimeMillis();
          
            // Only turn row red for high priority
            if (priority.equalsIgnoreCase("high priority")) {
                worker.setHasAlert(true);
                dashboardTable.refresh();
            }

            // Add to alert window list
            BPM_Alert alert = new BPM_Alert(
                    Integer.parseInt(worker.getWorkerId()),
                    alertText,
                    priority,
                    formatAlertTime(time),
                    bpm
            );
            AlertList.getAlerts().add(alert);

        } else if (payload != null) {
            // Fallback for plain string payloads
            alertText = payload.toString();
            priority = "high priority";
        }
        worker.setHasAlert(true);
        dashboardTable.refresh();

        // Show popup dialog
        Alert dialog = new Alert(Alert.AlertType.WARNING);
        dialog.setTitle("Health Alert");
        dialog.setHeaderText("Alert for: " + worker.getEmployeeName() + " (Watch " + watchId + ")");
        dialog.setContentText(alertText);
        dialog.showAndWait();

        // gets rid of red highlight in table
        worker.setHasAlert(false);
        dashboardTable.refresh();
    }

    private void handleEmployeeConnectionToWatch(Message message) {
        Object payload = message.getPayload();
        String employeeId = null;
        String watchId = message.getSender();

        if (payload instanceof Map<?, ?> data) {
            Object employeeObj = data.get("employeeId");
            Object watchObj = data.get("watchId");

            if (employeeObj != null) {
                employeeId = employeeObj.toString();
            }

            if (watchObj != null) {
                watchId = watchObj.toString();
            }
        } else if (payload != null) {
            employeeId = payload.toString();
        }

        if (employeeId == null || employeeId.isBlank() || watchId == null || watchId.isBlank()) {
            System.out.println("Warning: invalid employee connection payload: " + payload);

            Map<String, Object> errorPayload = managerClient.getErrorPayload(watchId);

            try {
                managerClient.sendConnectionError(watchId, "error", errorPayload);
            } catch (Exception e) {
                System.out.println("Error sending connection error: " + e.getMessage());
            }

            return;
        }

        Worker worker = findWorkerByID(employeeId);

        if (worker == null) {
            System.out.println("Warning: no worker found for employee ID: " + employeeId);
            return;
        }

        try {
            worker.setWatchId(watchId);
            System.out.println("Connected employee " + employeeId +
                    " (" + worker.getEmployeeName() + ") to watch " + watchId);
        } catch (Exception e) {
            System.out.println("Failed to associate watch " + watchId +
                    " to employee " + employeeId + ": " + e.getMessage());
        }
    }

    private void handleDataMessage(Message message) {
        Map<String, Object> data = (Map<String, Object>) message.getPayload();

        String watchId = (String) data.get("watchId");
        Integer bpm = toInteger(data.get("heartRate"));
        Integer steps = toInteger(data.get("steps"));
        Integer readiness = toInteger(data.get("readiness"));

        Worker worker = findWorkerByWatchID(watchId);

        if (worker != null) {
            worker.addHeartRate(bpm != null ? bpm : 0);
            baseline.checkForAlert(Integer.parseInt(worker.getWorkerId()), bpm == null ? 0 : bpm);
            worker.addSteps(steps != null ? steps : 0);
            worker.setReadinessScore(worker.getReadinessScore() == 0 ? readiness : worker.getReadinessScore());
            persistWorkerDailyMetrics(worker, bpm, readiness, steps);
            dashboardTable.refresh();
        } else {
            System.out.println("Warning: Received data for unknown worker ID: " + watchId);
            System.out.println("No match found for: " + watchId);
        }
    }

    private void persistWorkerDailyMetrics(Worker worker, Integer bpm, Integer readiness, Integer steps) {
        try {
            int employeeId = Integer.parseInt(worker.getWorkerId());

            if (!employeeDAO.employeeExists(employeeId)) {
                return;
            }

            employeeDAO.recordMetricSample(employeeId, bpm, readiness, steps);
        } catch (NumberFormatException e) {
            System.out.println("Skipping metric persistence for non-numeric employee id: "
                    + worker.getWorkerId());
        }
    }

    private Integer toInteger(Object obj) {
        if (obj == null) {
            return null;
        }

        return ((Number) obj).intValue();
    }

    private Worker findWorkerByID(String id) {
        for (Worker worker : masterData) {
            if (worker.getWorkerId().equals(id)) {
                return worker;
            }
        }

        return null;
    }

    private Worker findWorkerByWatchID(String id) {
        for (Worker worker : masterData) {
            if (!worker.getWatchId().isEmpty() && worker.getWatchId().equals(id)) {
                return worker;
            }
        }

        return null;
    }

    @FXML
    public void saveEndOfDay() {
        for (Worker worker : masterData) {
            worker.endDay();
        }
    }

    public void loadDatabaseData() {
        EmployeeDAO dao = new EmployeeDAO();

        javafx.concurrent.Task<List<Worker>> loadTask = new javafx.concurrent.Task<>() {
            @Override
            protected List<Worker> call() {
                return dao.getAllWorkers();
            }
        };

        loadTask.setOnSucceeded(event -> {
            List<Worker> loaded = loadTask.getValue();

            if (loaded == null) {
                loaded = List.of();
            }

            Map<String, String> watchByEmployeeId = new HashMap<>();
            Map<String, Boolean> alertByEmployeeId = new HashMap<>();

            for (Worker worker : masterData) {
                if (worker.getWatchId() != null && !worker.getWatchId().isEmpty()) {
                    watchByEmployeeId.put(worker.getWorkerId(), worker.getWatchId());
                }

                if (worker.isHasAlert()) {
                    alertByEmployeeId.put(worker.getWorkerId(), true);
                }
            }

            masterData.clear();
            masterData.addAll(loaded);

            for (Worker worker : masterData) {
                String watchId = watchByEmployeeId.get(worker.getWorkerId());

                if (watchId != null) {
                    worker.setWatchId(watchId);
                }

                if (Boolean.TRUE.equals(alertByEmployeeId.get(worker.getWorkerId()))) {
                    worker.setHasAlert(true);
                }
            }

            dashboardTable.refresh();
            System.out.println("Table updated successfully!");
        });

        loadTask.setOnFailed(event -> {
            System.out.println("Database load failed:");
            loadTask.getException().printStackTrace();
        });

        new Thread(loadTask).start();
    }

    private void setupFiltering() {
        searchField.textProperty().addListener((obs, oldVal, newVal) -> updatePredicate());
        minReadinessField.textProperty().addListener((obs, oldVal, newVal) -> updatePredicate());
        minBpmField.textProperty().addListener((obs, oldVal, newVal) -> updatePredicate());
        minStepsField.textProperty().addListener((obs, oldVal, newVal) -> updatePredicate());
    }

    private void updatePredicate() {
        filteredData.setPredicate(worker -> {
            String searchText = searchField.getText();

            if (searchText != null && !searchText.isEmpty()) {
                if (!worker.getEmployeeName().toLowerCase().contains(searchText.toLowerCase())) {
                    return false;
                }
            }

            Integer minReadiness = parseInteger(minReadinessField.getText());

            if (minReadiness != null && (worker.getReadinessScore() == null ||
                    worker.getReadinessScore() < minReadiness)) {
                return false;
            }

            Integer minBpm = parseInteger(minBpmField.getText());

            if (minBpm != null && (worker.getDailyAvgBpm() == null ||
                    worker.getDailyAvgBpm() < minBpm)) {
                return false;
            }

            Integer minSteps = parseInteger(minStepsField.getText());

            if (minSteps != null && (worker.getSteps() == null ||
                    worker.getSteps() < minSteps)) {
                return false;
            }

            return true;
        });
    }

    private Integer parseInteger(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }

        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @FXML
    private void clearFilters(ActionEvent event) {
        searchField.clear();
        minReadinessField.clear();
        minBpmField.clear();
        minStepsField.clear();
        filteredData.setPredicate(worker -> true);
    }

    @FXML
    private void handleOpenAccessibilitySettings(ActionEvent event) {
        try {
            Scene currentScene = ((Node) event.getSource()).getScene();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccessibilitySettings.fxml"));
            Parent root = loader.load();

            AccessibilitySettingsController.setMainScene(currentScene);

            Scene accessibilityScene = new Scene(root);
            AccessibilityManager.applySettings(accessibilityScene);

            Stage stage = new Stage();
            stage.setTitle("Accessibility Settings");
            stage.setScene(accessibilityScene);
            stage.setResizable(false);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.initOwner(currentScene.getWindow());
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleSwitchToReminderWindow(ActionEvent event) throws IOException {
        if (reminderScene == null) {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("ReminderWindow.fxml"));
            Parent root = loader.load();

            reminderScene = new Scene(root);

            ReminderWindowController controller = loader.getController();


            controller.setMainScene(mainScene);
            controller.setManager(managerClient);
            controller.setWorkers(masterData);
        }


        AccessibilityManager.applySettings(reminderScene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(reminderScene);
        stage.show();
    }

    @FXML
    public void handleSwitchToExportWindow(ActionEvent event) throws IOException {
        Scene currentMainScene = ((Node) event.getSource()).getScene();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("ExportWindow.fxml"));
        Parent root = loader.load();

        exportScene = new Scene(root);

        ExportWindowController exportController = loader.getController();
        exportController.setMainScene(currentMainScene);
        exportController.setWorkers(new ArrayList<>(masterData));

        AccessibilityManager.applySettings(exportScene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(exportScene);
        stage.show();
    }

    @FXML
    public void handleSwitchToAlertWindow(ActionEvent event) throws IOException {
        if (alertScene == null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AlertWindow.fxml"));
            Parent root = loader.load();

            alertScene = new Scene(root);

            alertController = loader.getController();
            alertController.setMainScene(mainScene);
        }

        AccessibilityManager.applySettings(alertScene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(alertScene);
        stage.show();
    }

    @FXML
    public void handleSwitchToAddEmployeeWindow(ActionEvent event) throws IOException {
        if (addEmployeeScene == null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddEmployee.fxml"));
            Parent root = loader.load();

            addEmployeeScene = new Scene(root);

            AddEmployeeController addEmployeeController = loader.getController();
            addEmployeeController.setMainScene(mainScene);
            addEmployeeController.setMainController(this);
        }

        AccessibilityManager.applySettings(addEmployeeScene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(addEmployeeScene);
        stage.show();
    }

    @FXML
    public void handleSwitchToDatabaseViewWindow(ActionEvent event) throws IOException {
        if (databaseViewScene == null) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("DatabaseViewWindow.fxml"));
            Parent root = loader.load();

            databaseViewScene = new Scene(root);

            databaseViewController = loader.getController();
            databaseViewController.setMainScene(mainScene);
        }

        databaseViewController.refreshData();
        AccessibilityManager.applySettings(databaseViewScene);

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(databaseViewScene);
        stage.show();
    }

    public void setMainScene(Scene scene) {
        this.mainScene = scene;
        AccessibilityManager.applySettings(scene);
    }

    private static String formatAlertTime(long timestamp) {
        String formatted = java.time.Instant.ofEpochMilli(timestamp)
                .atZone(java.time.ZoneId.systemDefault())
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        return formatted;
    }

}