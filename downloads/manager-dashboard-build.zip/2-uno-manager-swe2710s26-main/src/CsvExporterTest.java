/*
 * Course: SWE2710 - Software Tools & Process
 * Term: Spring 2026
 * Uno- Manager Project Tests
 * Author: Arianna Nunez
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

/**
 * -----------------------------------------------------------------------------
 * Tests that CSV files generate correctly when worker data exists.
 * -----------------------------------------------------------------------------
 */
public final class CsvExporterTest {

    private static final String FILE_NAME = "health_data.csv";

    @AfterEach
    public void cleanUp() {
        File file = new File(System.getProperty("user.home")
                + File.separator + "Downloads"
                + File.separator + FILE_NAME);

        if (file.exists()) {
            boolean deleted = file.delete();
            Assertions.assertTrue(deleted);
        }
    }

    @Test
    public void testCsvGeneratedWhenWorkersExist() throws Exception {

        List<Worker> workers = List.of(
                new Worker("Alice Smith", "1", "Watch-001", 85, 72, 10000),
                new Worker("Bob Jones", "2", "Watch-002", 90, 68, 9000)
        );

        File file = CsvExporter.exportToCsv(
                workers,
                LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 12, 31),
                true,
                true,
                true
        );

        Assertions.assertNotNull(file);
        Assertions.assertTrue(file.exists());
    }
}