import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

public final class CsvExporter {

    private CsvExporter() {
    }

    public static File exportToCsv(List<Worker> workers,
                                   LocalDate startDate,
                                   LocalDate endDate,
                                   boolean includeReadiness,
                                   boolean includeBpm,
                                   boolean includeSteps) throws IOException {

        String fileName = "health_data.csv";

        StringBuilder csvText = new StringBuilder();

        csvText.append("Start Date,End Date,Employee,Worker ID,Watch ID");

        if (includeReadiness) {
            csvText.append(",Readiness Score");
        }

        if (includeBpm) {
            csvText.append(",Daily Avg BPM");
        }

        if (includeSteps) {
            csvText.append(",Steps");
        }

        csvText.append("\n");

        for (Worker worker : workers) {
            csvText.append(csvValue(startDate)).append(",");
            csvText.append(csvValue(endDate)).append(",");
            csvText.append(csvValue(worker.getEmployeeName())).append(",");
            csvText.append(csvValue(worker.getWorkerId())).append(",");
            csvText.append(csvValue(worker.getWatchId()));

            if (includeReadiness) {
                csvText.append(",").append(csvValue(worker.getReadinessScore()));
            }

            if (includeBpm) {
                csvText.append(",").append(csvValue(worker.getDailyAvgBpm()));
            }

            if (includeSteps) {
                csvText.append(",").append(csvValue(worker.getSteps()));
            }

            csvText.append("\n");
        }

        Path downloadsFolder = Path.of(
                System.getProperty("user.home"),
                "Downloads"
        );

        Files.createDirectories(downloadsFolder);

        Path csvPath = downloadsFolder.resolve(fileName);

        Files.writeString(
                csvPath,
                csvText.toString(),
                StandardCharsets.UTF_8
        );

        return csvPath.toFile();
    }

    private static String csvValue(Object value) {
        if (value == null) {
            return "";
        }

        String text = value.toString();
        text = text.replace("\"", "\"\"");

        if (text.contains(",") || text.contains("\"") || text.contains("\n")) {
            return "\"" + text + "\"";
        }

        return text;
    }
}