


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Dist_Time_Tests {

    @Test
    void testWorkerTracksDistanceAutomatically() {
        Worker w = new Worker();

        w.watchUpdate(5.0, 0);
        w.watchUpdate(15.0, 3600000);

        assertEquals(15.0, w.getDistance());
    }

    @Test
    void testAverageSpeedCalculation() {
        Worker w = new Worker();

        w.watchUpdate(10.0, 0);
        w.watchUpdate(20.0, 3600000);

        assertEquals(20.0, w.getAvgSpeed());
    }

    @Test
    void testManagerCanViewWorkers() {
        WorkerList list = new WorkerList();

        Worker w1 = new Worker();
        Worker w2 = new Worker();

        list.addWorker(w1);
        list.addWorker(w2);

        assertEquals(2, list.getWorkers().size());
    }

    @Test
    void testAddWorker() {
        WorkerList list = new WorkerList();
        Worker worker = new Worker();

        list.addWorker(worker);

        assertTrue(list.getWorkers().contains(worker));
    }

    @Test
    void testRemoveWorker() {
        WorkerList list = new WorkerList();
        Worker worker = new Worker();

        list.addWorker(worker);
        list.removeWorker(worker);

        assertEquals(0, list.getWorkers().size());
    }

    @Test
    void testWorkerWithNoUpdates() {
        Worker w = new Worker();

        assertEquals(0, w.getDistance());
        assertEquals(0, w.getAvgSpeed());
    }

    @Test
    void testSingleUpdateNoSpeed() {
        Worker w = new Worker();

        w.watchUpdate(5.0, 1000);

        assertEquals(0, w.getAvgSpeed());
    }

    @Test
    void testSameTimestampUpdates() {
        Worker w = new Worker();

        w.watchUpdate(5.0, 1000);
        w.watchUpdate(5.0, 1000);

        assertEquals(0, w.getAvgSpeed());
    }

    @Test
    void testWorkersTrackIndependently() {
        Worker w1 = new Worker();
        Worker w2 = new Worker();

        w1.watchUpdate(10, 0);
        w1.watchUpdate(30, 3600000);

        w2.watchUpdate(5, 0);
        w2.watchUpdate(5, 1800000);

        assertEquals(30, w1.getDistance());
        assertEquals(5, w2.getDistance());

        assertEquals(30, w1.getAvgSpeed());
        assertEquals(10, w2.getAvgSpeed());
    }

    @Test
    void testAddNullWorkerThrowsException() {
        WorkerList list = new WorkerList();

        assertThrows(IllegalArgumentException.class,
                () -> list.addWorker(null));
    }

    @Test
    void testNegativeDistanceRejected() {
        Worker w = new Worker();
        w.watchUpdate(10, 1000);
        assertThrows(IllegalArgumentException.class,
                () -> w.watchUpdate(5.0, 2000));
    }

    @Test
    void testRemoveWorkerNotInList() {
        WorkerList list = new WorkerList();
        Worker worker = new Worker();

        list.removeWorker(worker);

        assertEquals(0, list.getWorkers().size());
    }

    @Test
    void testLargeTimeGapSpeedCalculation() {
        Worker w = new Worker();

        w.watchUpdate(100.0, 0);
        w.watchUpdate(150.0, 86400000);

        assertTrue(w.getAvgSpeed() > 0);
    }
}
