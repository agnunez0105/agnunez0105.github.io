

public class BPM_Alert {

    // Unique identifier for the employee associated with this alert
    private int employeeId;

    // Description of the alert (e.g., "Too High BPM Alert")
    private String message;

    // Severity level of the alert (e.g., High, Medium, Low)
    private String priority;

    // Timestamp indicating when the alert was generated
    private String time;

    // The BPM value that triggered the alert
    private double bpm;

    /**
     * Constructs a new BPM_Alert object with all required alert details.
     *
     * @param employeeId the ID of the employee
     * @param message the alert message describing the issue
     * @param priority the severity level of the alert
     * @param time the time the alert was created
     * @param bpm the BPM reading that triggered the alert
     */
    public BPM_Alert(int employeeId, String message, String priority, String time, double bpm) {
        this.employeeId = employeeId;
        this.message = message;
        this.priority = priority;
        this.time = time;
        this.bpm = bpm;
    }

    // Returns the employee ID associated with the alert
    public int getEmployeeId() {
        return employeeId;
    }

    // Returns the alert message
    public String getMessage() {
        return message;
    }

    // Returns the priority level of the alert
    public String getPriority() {
        return priority;
    }

    // Returns the timestamp of when the alert was created
    public String getTime() {
        return time;
    }

    /**
     * Returns a simple string representation of the alert.
     * Useful for debugging or logging.
     */
    public String sendAlert() {
        return employeeId + " " + message + " " + priority + " " + time;
    }

    // Returns the BPM value that triggered the alert
    public double getBpm() {
        return bpm;
    }
}