import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.stage.Stage;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExportWindowController {

    @FXML private DatePicker startDate;
    @FXML private DatePicker endDate;
    @FXML private MenuButton employeeMenu;
    @FXML private CheckBox readinessCheck;
    @FXML private CheckBox dailyAvgCheck;
    @FXML private CheckBox stepsCheck;
    @FXML private CheckBox allStatsCheck;
    @FXML private Button exportButton;

    private Scene mainScene;

    private final List<Worker> workers = new ArrayList<>();
    private final List<CheckMenuItem> employeeItems = new ArrayList<>();

    public void setMainScene(Scene scene) {
        this.mainScene = scene;
    }

    public void setWorkers(List<Worker> dashboardWorkers) {
        workers.clear();

        if (dashboardWorkers != null) {
            workers.addAll(dashboardWorkers);
        }

        setupEmployeeMenu();
    }

    @FXML
    public void initialize() {
        setupAllStatsCheckBox();

        if (exportButton != null) {
            exportButton.setOnAction(this::handleExport);
        }

        setupEmployeeMenu();
    }

    @FXML
    public void handleExport(ActionEvent event) {
        try {
            LocalDate start = startDate.getValue();
            LocalDate end = endDate.getValue();

            if (start == null || end == null) {
                showAlert(Alert.AlertType.ERROR,
                        "Missing Dates",
                        "Please select a start date and an end date.");
                return;
            }

            if (end.isBefore(start)) {
                showAlert(Alert.AlertType.ERROR,
                        "Invalid Dates",
                        "End date cannot be before start date.");
                return;
            }

            List<Worker> selectedWorkers = getSelectedWorkers();

            if (selectedWorkers.isEmpty()) {
                showAlert(Alert.AlertType.ERROR,
                        "No Employees Selected",
                        "Please select at least one employee.");
                return;
            }

            boolean includeReadiness = readinessCheck.isSelected();
            boolean includeBpm = dailyAvgCheck.isSelected();
            boolean includeSteps = stepsCheck.isSelected();

            if (allStatsCheck.isSelected()) {
                includeReadiness = true;
                includeBpm = true;
                includeSteps = true;
            }

            if (!includeReadiness && !includeBpm && !includeSteps) {
                showAlert(Alert.AlertType.ERROR,
                        "No Data Selected",
                        "Please select at least one data field.");
                return;
            }

            File file = CsvExporter.exportToCsv(
                    selectedWorkers,
                    start,
                    end,
                    includeReadiness,
                    includeBpm,
                    includeSteps
            );

            if (file != null && file.exists()) {
                showAlert(Alert.AlertType.INFORMATION,
                        "Export Successful",
                        "CSV saved to Downloads:\n" + file.getAbsolutePath());
            } else {
                showAlert(Alert.AlertType.ERROR,
                        "Export Failed",
                        "The CSV file was not created.");
            }

        } catch (Exception exception) {
            exception.printStackTrace();

            showAlert(Alert.AlertType.ERROR,
                    "Export Error",
                    exception.getMessage());
        }
    }

    @FXML
    public void handleSwitchToMainWindow(ActionEvent event) {
        if (mainScene == null) {
            showAlert(Alert.AlertType.ERROR,
                    "Navigation Error",
                    "Main scene has not been set.");
            return;
        }

        Stage stage = (Stage) ((Node) event.getSource())
                .getScene()
                .getWindow();

        stage.setScene(mainScene);
        stage.show();
    }

    private void setupAllStatsCheckBox() {
        if (allStatsCheck == null) {
            return;
        }

        allStatsCheck.setOnAction(event -> {
            boolean selected = allStatsCheck.isSelected();

            readinessCheck.setSelected(selected);
            dailyAvgCheck.setSelected(selected);
            stepsCheck.setSelected(selected);
        });
    }

    private void setupEmployeeMenu() {
        if (employeeMenu == null) {
            return;
        }

        employeeMenu.getItems().clear();
        employeeItems.clear();

        CheckMenuItem allEmployees = new CheckMenuItem("All Employees");
        allEmployees.setSelected(true);

        allEmployees.setOnAction(event -> {
            for (CheckMenuItem item : employeeItems) {
                item.setSelected(allEmployees.isSelected());
            }

            updateEmployeeMenuText();
        });

        employeeMenu.getItems().add(allEmployees);

        for (Worker worker : workers) {
            CheckMenuItem item = new CheckMenuItem(worker.getEmployeeName());
            item.setSelected(true);

            item.setOnAction(event -> updateEmployeeMenuText());

            employeeItems.add(item);
            employeeMenu.getItems().add(item);
        }

        updateEmployeeMenuText();
    }

    private List<Worker> getSelectedWorkers() {
        List<Worker> selectedWorkers = new ArrayList<>();

        for (int i = 0; i < employeeItems.size(); i++) {
            if (employeeItems.get(i).isSelected()) {
                selectedWorkers.add(workers.get(i));
            }
        }

        return selectedWorkers;
    }

    private void updateEmployeeMenuText() {
        int count = 0;

        for (CheckMenuItem item : employeeItems) {
            if (item.isSelected()) {
                count++;
            }
        }

        if (workers.isEmpty()) {
            employeeMenu.setText("No Employees Available");
        } else if (count == workers.size()) {
            employeeMenu.setText("All Employees");
        } else if (count == 0) {
            employeeMenu.setText("Select Employees");
        } else if (count == 1) {
            employeeMenu.setText("1 Employee Selected");
        } else {
            employeeMenu.setText(count + " Employees Selected");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message == null ? "Unknown error." : message);
        alert.showAndWait();
    }
}