import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WorkerReconnectionTest {

    private Worker worker;

    @BeforeEach
    public void setUp() {
        // Create a worker with no watch assigned yet
        worker = new Worker("Jane Doe", "82");
    }

    @Test
    public void testInitialWatchAssignment() {
        // Simulate first connection message
        worker.setWatchId("watch1");
        assertEquals("watch1", worker.getWatchId());
    }

    @Test
    public void testWatchReconnectsSameEmployee() {
        // Simulate first connection
        worker.setWatchId("watch1");
        assertEquals("watch1", worker.getWatchId());

        // Simulate watch disconnect then reconnect with same watchId
        worker.setWatchId("");
        worker.setWatchId("watch1");    
        assertEquals("watch1", worker.getWatchId(),
                "Watch should reconnect to the same employee after disconnect");
    }

    @Test
    public void testDifferentWatchOverwritesAssignment() {
        // First watch connects
        worker.setWatchId("watch1");
        assertEquals("watch1", worker.getWatchId());

        // A different watch sends the same employeeId (e.g. watch was replaced)
        worker.setWatchId("watch2");
        assertEquals("watch2", worker.getWatchId(),
                "New watch should overwrite old watch assignment for same employee");
    }

    @Test
    public void testWorkerDataPreservedAfterReconnect() {
        // Set up some worker state before disconnect
        worker.setWatchId("watch1");
        worker.addHeartRate(80);
        worker.addHeartRate(90);
        worker.addSteps(500);

        // Simulate disconnect and reconnect
        worker.setWatchId("");
        worker.setWatchId("watch1");

        // Data should still be intact after reconnect
        assertEquals("watch1", worker.getWatchId());
        assertEquals(85, worker.getDailyAvgBpm(),
                "Heart rate average should be preserved after reconnect");
        assertEquals(500, worker.getSteps(),
                "Steps should be preserved after reconnect");
    }

    @Test
    public void testWorkerStartsWithNoWatch() {
        // Worker created with no watch should have empty watchId
        assertEquals("", worker.getWatchId(),
                "Worker should start with no watch assigned");
    }
}