

import javafx.scene.control.Alert;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Baseline {


    /**
     * Retrieves the most recent BPM value recorded for a given employee.
     * This is used as the "current BPM" for alert comparison.
     *
     * @param employeeId the ID of the employee
     * @return most recent BPM value, or 0 if no data exists
     */
    public static double getMostRecentBPM(int employeeId) {

        String sql = """
            SELECT bpm
            FROM metrics
            WHERE employee_id = ?
            ORDER BY id DESC 
            LIMIT 1
            """;

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) return rs.getDouble("bpm");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    /**
     * Calculates the baseline BPM for an employee.
     * The baseline is computed as the average of the last 7 BPM readings,
     * excluding the most recent reading (used as current BPM).
     *
     * A minimum of 8 total records is required before a baseline is computed.
     *
     * @param employeeId the ID of the employee
     * @return calculated baseline BPM
     */
    public static double getBaselineBPM(int employeeId) {

        String countSql = "SELECT COUNT(*) FROM metrics WHERE employee_id = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement countStmt = conn.prepareStatement(countSql)) {

            countStmt.setInt(1, employeeId);
            ResultSet countRs = countStmt.executeQuery();

            if (countRs.next()) {
                int count = countRs.getInt(1);

                // Require enough historical data before computing baseline
                if (count < 8) {
                    return 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Compute average of last 7 readings
        String sql = """
            SELECT AVG(bpm) AS avg_bpm
            FROM (
                SELECT bpm
                FROM metrics
                WHERE employee_id = ?
                ORDER BY id DESC
                LIMIT 7
            )
            """;

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, employeeId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble("avg_bpm");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    /**
     * Checks whether the current BPM exceeds the baseline threshold.
     * If the current BPM is more than 30 BPM above the baseline,
     * an alert is created and added to the global AlertList.
     *
     * @param employeeId the ID of the employee
     * @param currentBpm the most recent BPM reading
     */
    public static void checkForAlert(int employeeId, double currentBpm) {

        double baseline = getBaselineBPM(employeeId);

        if(baseline != 0) {

            // Ignore invalid or incomplete data
            if (baseline == 0 || currentBpm == 0) {
                return;
            }

            // Alert condition: significant spike above baseline
            if (currentBpm > baseline + 80) {

                // Timestamp for when alert was generated
                String time = LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                // Create alert object
                BPM_Alert alert = new BPM_Alert(
                        employeeId,
                        "High BPM Alert, BPM exceeded healthy working range",
                        "High Priority",
                        time,
                        currentBpm
                );

                // Store alert globally for UI access
                AlertList.addAlert(alert);

            } else if (currentBpm > baseline + 60) {

                // Timestamp for when alert was generated
                String time = LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                // Create alert object
                BPM_Alert alert = new BPM_Alert(
                        employeeId,
                        "BPM is at edge of healthy range",
                        "Medium Priority",
                        time,
                        currentBpm
                );

                // Store alert globally for UI access
                AlertList.addAlert(alert);
            } else if (currentBpm > baseline + 30) {

                // Timestamp for when alert was generated
                String time = LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                // Create alert object
                BPM_Alert alert = new BPM_Alert(
                        employeeId,
                        "BPM is in working range",
                        "Low Priority",
                        time,
                        currentBpm
                );

                // Store alert globally for UI access
                AlertList.addAlert(alert);
            }
        } else {
            System.out.println("Employee has baseline of 0");
        }
    }

}
