//import java.sql.Connection;
//import java.sql.Statement;
//
//public class AlertRetrievalTester {
//
//    public static void main(String[] args) {
//        DatabaseManager.initializeDatabase();
//        EmployeeDAO dao = new EmployeeDAO();
//        clearTables();
//
//
//        // TEST 1: Less than 7 records
//
//        dao.addEmployee("Alice");
//        dao.recordBPM(1, 70);
//        dao.recordBPM(1, 72);
//        dao.recordBPM(1, 68);
//        dao.recordBPM(1, 71);
//        dao.recordBPM(1, 69);
//        dao.recordBPM(1, 70);
//        dao.recordBPM(1, 71); // 7th
//
//        System.out.println("Test 1 (7 records, no alert)");
//        printBaselineComparison(1);
//        System.out.println("----------------------");
//
//        // -------------------------------
//        // TEST 2: Exactly 7 records
//        // -------------------------------
//        dao.addEmployee("Bob");
//        dao.recordBPM(2, 70);
//        dao.recordBPM(2, 72);
//        dao.recordBPM(2, 71);
//        dao.recordBPM(2, 69);
//        dao.recordBPM(2, 70);
//        dao.recordBPM(2, 71);
//        dao.recordBPM(2, 72); // baseline done
//
//        dao.recordBPM(2, 110); // trigger (> baseline + 30)
//
//        System.out.println("Test 2 (trigger alert)");
//        printBaselineComparison(2);
//        System.out.println("----------------------");
//
//
//        // TEST 3: More than 7 records
//        dao.addEmployee("Charlie");
//        dao.recordBPM(3, 60);
//        dao.recordBPM(3, 65);
//        dao.recordBPM(3, 70);
//        dao.recordBPM(3, 75);
//        dao.recordBPM(3, 80);
//        dao.recordBPM(3, 85);
//        dao.recordBPM(3, 90);
//        dao.recordBPM(3, 95);
//        dao.recordBPM(3, 140); // trigger
//
//        System.out.println("Test 3 (>7 records)");
//        printBaselineComparison(3);
//        System.out.println("----------------------");
//
//        // -------------------------------
//        // TEST 4: No records
//        // -------------------------------
//        dao.addEmployee("David");
//
//        System.out.println("Test 4 (<7 records)");
//        printBaselineComparison(4);
//        System.out.println("----------------------");
//
//
//        // TEST 5: Gaps between work days
//        dao.addEmployee("Eve");
//        dao.recordBPM(5, 50);
//        dao.recordBPM(5, 60);
//        dao.recordBPM(5, 70);
//        dao.recordBPM(5, 80);
//        dao.recordBPM(5, 90);
//
//        System.out.println("Test 5 (gaps / <7 records)");
//        printBaselineComparison(5);
//        System.out.println("----------------------");
//    }
//
//    // Helper: compute baseline, most recent BPM, and compare
//    private static void printBaselineComparison(int employeeId) {
//        double baseline = Baseline.getBaselineBPM(employeeId);
//        double recent = Baseline.getMostRecentBPM(employeeId);
//
//        if (baseline == 0 || recent == 0) {
//            System.out.println("Not enough data (need at least 7 records) for employee " + employeeId);
//            return;
//        }
//
//        double threshold = baseline + 30;
//
//        System.out.println("Baseline BPM (last 7): " + baseline);
//        System.out.println("Most recent BPM: " + recent);
//        System.out.println("Threshold (baseline + 30): " + threshold);
//
//        if (recent > threshold) {
//            System.out.println("🚨 High Priority Alert!");
//        } else {
//            System.out.println("BPM is within normal range.");
//        }
//    }
//
//    // Helper to reset tables
//    private static void clearTables() {
//        try (Connection conn = DatabaseManager.getConnection();
//             Statement stmt = conn.createStatement()) {
//
//            stmt.execute("DELETE FROM metrics;");
//            stmt.execute("DELETE FROM employees;");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}