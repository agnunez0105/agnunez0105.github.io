import MQTTServer.*;
import simDataApp.SimulatedDataService;

/**
 * -----------------------------------------------------------------------------
 * Demonstrates the MQTT-style publish/subscribe system.
 *
 * @author Arianna Nunez, Zoe Kirkman
 * @version 1.0
 * @since 2026
 * -----------------------------------------------------------------------------
 */

public class MQTTMain {

    public static void main(String[] args) {

        try {

            SimulatedDataService sim = new SimulatedDataService();
            sim.start();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());;
        }
    }
}