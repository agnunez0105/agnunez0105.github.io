import javafx.beans.property.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Worker {

    private final String employee;
    private final IntegerProperty readinessScore = new SimpleIntegerProperty();
    private final IntegerProperty dailyAvgBpm    = new SimpleIntegerProperty();
    private final IntegerProperty steps          = new SimpleIntegerProperty();

    private String workerId;
    private String watchId;

    private double totalDistance;
    private double avgSpeed;
    private List<Integer> heartRates;
    private boolean hasAlert = false;

    private long startTime      = -1;
    private long lastUpdateTime = -1;

    private static int idCounter = 0;

    private final Map<LocalDate, DailyRecord> history = new LinkedHashMap<>();

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    public Worker(String employee, String id, String watch,
                  Integer readinessScore, Integer dailyAvgBpm, Integer steps) {
        this.employee = employee;
        this.workerId = id;
        this.watchId  = watch;
        this.readinessScore.set(readinessScore != null ? readinessScore : 0);
        this.dailyAvgBpm.set(dailyAvgBpm       != null ? dailyAvgBpm   : 0);
        this.steps.set(steps                   != null ? steps         : 0);
        heartRates = new ArrayList<>();
    }

    public Worker(String employee, String watch, String workerId) {
        this.employee  = employee;
        this.watchId   = watch;
        this.workerId  = workerId;
        this.readinessScore.set(0);
        this.dailyAvgBpm.set(0);
        this.steps.set(0);
        totalDistance = 0;
        avgSpeed      = 0;
        heartRates    = new ArrayList<>();
    }

    public Worker(String employee, String workerId) {
        this.employee = employee;
        this.watchId  = "";
        this.workerId = workerId;
        this.readinessScore.set(0);
        this.dailyAvgBpm.set(0);
        this.steps.set(0);
        totalDistance = 0;
        avgSpeed      = 0;
        heartRates    = new ArrayList<>();
    }

    public Worker(String employee, Integer readinessScore, Integer bpm, Integer steps) {
        this.employee = employee;
        this.readinessScore.set(readinessScore);
        this.dailyAvgBpm.set(bpm);
        this.steps.set(steps);
        workerId      = Integer.toString(idCounter++);
        watchId       = "";
        totalDistance = 0;
        avgSpeed      = 0;
        heartRates    = new ArrayList<>();
    }

    public Worker() {
        this.employee = "";
        this.steps.set(0);
        heartRates = new ArrayList<>();
    }

    // -------------------------------------------------------------------------
    // History / daily record methods
    // -------------------------------------------------------------------------

    /** Records the worker's current live values for the given date. */
    public void recordDay(LocalDate date) {
        history.put(date, new DailyRecord(
                date,
                readinessScore.get(),
                dailyAvgBpm.get(),
                steps.get()
        ));
    }

    /** Records explicit values for a given date (for seeding or DB import). */
    public void recordDay(LocalDate date, int readiness, int bpm, int steps) {
        history.put(date, new DailyRecord(date, readiness, bpm, steps));
    }

    /** Returns all records whose date falls within [start, end] inclusive. */
    public List<DailyRecord> getRecordsInRange(LocalDate start, LocalDate end) {
        List<DailyRecord> result = new ArrayList<>();
        for (Map.Entry<LocalDate, DailyRecord> entry : history.entrySet()) {
            LocalDate d = entry.getKey();
            if (!d.isBefore(start) && !d.isAfter(end)) {
                result.add(entry.getValue());
            }
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // Property accessors (required by TableView bindings)
    // -------------------------------------------------------------------------

    public IntegerProperty readinessScoreProperty() { return readinessScore; }
    public IntegerProperty dailyAvgBpmProperty()    { return dailyAvgBpm;    }
    public IntegerProperty stepsProperty()          { return steps;          }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public String  getEmployeeName()    { return employee;             }
    public Integer getReadinessScore()  { return readinessScore.get(); }
    public Integer getDailyAvgBpm()     { return dailyAvgBpm.get();   }
    public Integer getSteps()           { return steps.get();         }
    public String  getWatchId()         { return watchId;             }
    public String  getWorkerId()        { return workerId;            }
    public double  getDistance()        { return totalDistance;       }
    public double  getAvgSpeed()        { return avgSpeed;            }
    public boolean isHasAlert()         { return hasAlert;            }

    // -------------------------------------------------------------------------
    // Setters
    // -------------------------------------------------------------------------

    public void setReadinessScore(Integer value) {
        this.readinessScore.set(value == null ? 0 : value);
    }

    public void setWatchId(String watch)       { this.watchId  = watch;   }
    public void setHasAlert(boolean hasAlert)  { this.hasAlert = hasAlert; }

    // -------------------------------------------------------------------------
    // Live-data update methods
    // -------------------------------------------------------------------------

    public void addSteps(int newSteps) {
        steps.set(steps.get() + newSteps);
    }

    public void addHeartRate(int heartRate) {
        heartRates.add(heartRate);
        calculateAvgBpm();
    }

    private void calculateAvgBpm() {
        int total = 0;
        for (Integer hr : heartRates) total += hr;
        dailyAvgBpm.set(total / heartRates.size());
    }

    public void watchUpdate(double distance, long timestamp) {
        if (distance < totalDistance)
            throw new IllegalArgumentException("Distance cannot decrease.");
        if (startTime == -1) startTime = timestamp;
        totalDistance  = distance;
        lastUpdateTime = timestamp;
        calculateSpeed();
    }

    private void calculateSpeed() {
        if (startTime == lastUpdateTime) return;
        double hours = (lastUpdateTime - startTime) / 3_600_000.0;
        if (hours > 0) avgSpeed = totalDistance / hours;
    }

    /**
     * Resets all live daily values.
     * Call recordDay(date) BEFORE this if you want to preserve today's data.
     */
    public void endDay() {
        readinessScore.set(0);
        dailyAvgBpm.set(0);
        steps.set(0);
        totalDistance  = 0;
        avgSpeed       = 0;
        heartRates     = new ArrayList<>();
        startTime      = -1;
        lastUpdateTime = -1;
        watchId        = "";
    }

    // -------------------------------------------------------------------------
    // Stubs (kept for compatibility)
    // -------------------------------------------------------------------------

    public char[]  getId()             { return null; }
    public String  getRole()           { return null; }
    public char[]  getHoursWorked()    { return null; }
    public String  getLastActiveDate() { return null; }
}